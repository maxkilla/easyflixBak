# EasyFlix2
This website provides streaming options for movies and TV shows.

## Website

Check out the live website [here](https://anilove31.github.io/EasyFlix2/).
